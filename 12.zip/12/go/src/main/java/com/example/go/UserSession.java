package com.example.go;

public class UserSession {
    private static UserSession instance;
    private String email;
    private String username;
    private int coins;
    
    private UserSession() {
        this.coins = 10; // Default coins
    }
    
    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }
    
    public void login(String email, String username) {
        this.email = email;
        this.username = username;
    }
    
    public void logout() {
        this.email = null;
        this.username = null;
        this.coins = 10; // Reset to default
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getUsername() {
        return username;
    }
    
    public int getCoins() {
        return coins;
    }
    
    public void setCoins(int coins) {
        this.coins = coins;
    }
    
    public boolean isLoggedIn() {
        return email != null && username != null;
    }
}
