package com.example.go;

import java.io.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class NetworkManager {
    
    public enum MessageType {
        MOVE, GAME_START, GAME_END, PLAYER_JOINED, PLAYER_LEFT, CHAT
    }
    
    public static class GameMessage implements Serializable {
        private MessageType type;
        private String data;
        private int row, col;
        private String playerName;
        
        public GameMessage(MessageType type, String data) {
            this.type = type;
            this.data = data;
        }
        
        public GameMessage(MessageType type, int row, int col, String playerName) {
            this.type = type;
            this.row = row;
            this.col = col;
            this.playerName = playerName;
        }
        
        // Getters and setters
        public MessageType getType() { return type; }
        public String getData() { return data; }
        public int getRow() { return row; }
        public int getCol() { return col; }
        public String getPlayerName() { return playerName; }
    }
    
    public static class GameServer {
        private ServerSocket serverSocket;
        private Socket clientSocket;
        private ObjectOutputStream out;
        private ObjectInputStream in;
        private BlockingQueue<GameMessage> messageQueue;
        private boolean isRunning;
        private Thread serverThread;
        
        public GameServer(int port) throws IOException {
            serverSocket = new ServerSocket(port);
            messageQueue = new LinkedBlockingQueue<>();
            isRunning = true;
        }
        
        public void startServer() {
            serverThread = new Thread(() -> {
                try {
                    System.out.println("Server waiting for client connection...");
                    clientSocket = serverSocket.accept();
                    System.out.println("Client connected!");
                    
                    out = new ObjectOutputStream(clientSocket.getOutputStream());
                    in = new ObjectInputStream(clientSocket.getInputStream());
                    
                    // Send game start message
                    sendMessage(new GameMessage(MessageType.GAME_START, "Game started!"));
                    
                    // Listen for messages
                    while (isRunning && !clientSocket.isClosed()) {
                        try {
                            GameMessage message = (GameMessage) in.readObject();
                            messageQueue.offer(message);
                        } catch (IOException | ClassNotFoundException e) {
                            if (isRunning) {
                                System.out.println("Client disconnected");
                                break;
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            serverThread.start();
        }
        
        public void sendMessage(GameMessage message) {
            try {
                if (out != null) {
                    out.writeObject(message);
                    out.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        public GameMessage receiveMessage() {
            try {
                return messageQueue.poll();
            } catch (Exception e) {
                return null;
            }
        }
        
        public void stopServer() {
            isRunning = false;
            try {
                if (clientSocket != null) clientSocket.close();
                if (serverSocket != null) serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        public int getPort() {
            return serverSocket.getLocalPort();
        }
    }
    
    public static class GameClient {
        private Socket socket;
        private ObjectOutputStream out;
        private ObjectInputStream in;
        private BlockingQueue<GameMessage> messageQueue;
        private boolean isConnected;
        private Thread clientThread;
        
        public GameClient(String host, int port) throws IOException {
            socket = new Socket(host, port);
            messageQueue = new LinkedBlockingQueue<>();
            isConnected = true;
        }
        
        public void startClient() {
            clientThread = new Thread(() -> {
                try {
                    out = new ObjectOutputStream(socket.getOutputStream());
                    in = new ObjectInputStream(socket.getInputStream());
                    
                    // Listen for messages
                    while (isConnected && !socket.isClosed()) {
                        try {
                            GameMessage message = (GameMessage) in.readObject();
                            messageQueue.offer(message);
                        } catch (IOException | ClassNotFoundException e) {
                            if (isConnected) {
                                System.out.println("Server disconnected");
                                break;
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            clientThread.start();
        }
        
        public void sendMessage(GameMessage message) {
            try {
                if (out != null) {
                    out.writeObject(message);
                    out.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        public GameMessage receiveMessage() {
            try {
                return messageQueue.poll();
            } catch (Exception e) {
                return null;
            }
        }
        
        public void disconnect() {
            isConnected = false;
            try {
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        public boolean isConnected() {
            return isConnected && !socket.isClosed();
        }
    }
}
