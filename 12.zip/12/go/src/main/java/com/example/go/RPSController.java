package com.example.go;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class RPSController implements Initializable {

    // Player names
    private String player1Name = "Player 1";
    private String player2Name = "Player 2";
    
    // Scores
    private int player1Score = 0;
    private int player2Score = 0;
    
    // Game state
    private boolean player1Chosen = false;
    private boolean player2Chosen = false;
    private String player1Choice = "";
    private String player2Choice = "";
    
    // FXML elements
    @FXML private Label player1NameLabel;
    @FXML private Label player2NameLabel;
    @FXML private Label player1ScoreLabel;
    @FXML private Label player2ScoreLabel;
    @FXML private Label player1ChoiceLabel;
    @FXML private Label player2ChoiceLabel;
    @FXML private Label resultLabel;
    @FXML private ImageView player1ImageView;
    @FXML private ImageView player2ImageView;
    
    // Player 1 buttons
    @FXML private Button player1RockBtn;
    @FXML private Button player1PaperBtn;
    @FXML private Button player1ScissorBtn;
    
    // Player 2 buttons
    @FXML private Button player2RockBtn;
    @FXML private Button player2PaperBtn;
    @FXML private Button player2ScissorBtn;
    
    // Control buttons
    @FXML private Button nextRoundBtn;
    @FXML private Button restartBtn;
    @FXML private Button homeBtn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set initial player names
        player1NameLabel.setText(player1Name);
        player2NameLabel.setText(player2Name);
        updateScores();
        resetChoices();
    }

    public void setPlayerNames(String player1, String player2) {
        this.player1Name = player1;
        this.player2Name = player2;
        player1NameLabel.setText(player1Name);
        player2NameLabel.setText(player2Name);
    }

    private void updateScores() {
        player1ScoreLabel.setText("Score: " + player1Score);
        player2ScoreLabel.setText("Score: " + player2Score);
    }

    private void resetChoices() {
        player1Chosen = false;
        player2Chosen = false;
        player1Choice = "";
        player2Choice = "";
        
        player1ChoiceLabel.setText("Choose your move!");
        player2ChoiceLabel.setText("Choose your move!");
        resultLabel.setText("Choose your moves!");
        
        // Reset images
        player1ImageView.setImage(null);
        player2ImageView.setImage(null);
        
        // Enable all buttons
        enablePlayerButtons(true);
        nextRoundBtn.setVisible(false);
    }

    private void enablePlayerButtons(boolean enable) {
        player1RockBtn.setDisable(!enable);
        player1PaperBtn.setDisable(!enable);
        player1ScissorBtn.setDisable(!enable);
        player2RockBtn.setDisable(!enable);
        player2PaperBtn.setDisable(!enable);
        player2ScissorBtn.setDisable(!enable);
    }

    private void makeChoice(int player, String choice) {
        if (player == 1) {
            player1Choice = choice;
            player1Chosen = true;
            player1ChoiceLabel.setText("Chosen: " + choice);
            setPlayerImage(player1ImageView, choice);
        } else {
            player2Choice = choice;
            player2Chosen = true;
            player2ChoiceLabel.setText("Chosen: " + choice);
            setPlayerImage(player2ImageView, choice);
        }
        
        // Check if both players have chosen
        if (player1Chosen && player2Chosen) {
            evaluateRound();
        }
    }

    private void setPlayerImage(ImageView imageView, String choice) {
        try {
            String imagePath = "";
            switch (choice.toLowerCase()) {
                case "rock":
                    imagePath = "/com/example/go/images/rock.png";
                    break;
                case "paper":
                    imagePath = "/com/example/go/images/paper.png";
                    break;
                case "scissor":
                    imagePath = "/com/example/go/images/Scissor.png";
                    break;
            }
            if (!imagePath.isEmpty()) {
                Image image = new Image(getClass().getResourceAsStream(imagePath));
                imageView.setImage(image);
            }
        } catch (Exception e) {
            System.out.println("Error loading image: " + e.getMessage());
        }
    }

    private void evaluateRound() {
        enablePlayerButtons(false);
        
        String result = determineWinner(player1Choice, player2Choice);
        resultLabel.setText(result);
        
        // Update scores
        if (result.contains(player1Name + " wins")) {
            player1Score++;
        } else if (result.contains(player2Name + " wins")) {
            player2Score++;
        }
        
        updateScores();
        
        // Check for game end
        if (player1Score >= 5 || player2Score >= 5) {
            endGame();
        } else {
            nextRoundBtn.setVisible(true);
        }
    }

    private String determineWinner(String choice1, String choice2) {
        if (choice1.equals(choice2)) {
            return "It's a Draw!";
        }
        
        if ((choice1.equals("rock") && choice2.equals("scissor")) ||
            (choice1.equals("paper") && choice2.equals("rock")) ||
            (choice1.equals("scissor") && choice2.equals("paper"))) {
            return player1Name + " wins!";
        } else {
            return player2Name + " wins!";
        }
    }

    private void endGame() {
        String winner = (player1Score >= 5) ? player1Name : player2Name;
        resultLabel.setText("🎉 " + winner + " wins the match!");
        
        // Show restart option
        restartBtn.setVisible(true);
        
        // Show alert
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Game Over!");
        alert.setHeaderText("Match Complete!");
        alert.setContentText("🎉 " + winner + " wins the match!\n\nFinal Score:\n" + 
                           player1Name + ": " + player1Score + "\n" + 
                           player2Name + ": " + player2Score);
        alert.showAndWait();
    }

    // Player 1 action methods
    @FXML
    private void player1ChooseRock(ActionEvent event) {
        if (!player1Chosen) {
            makeChoice(1, "rock");
        }
    }

    @FXML
    private void player1ChoosePaper(ActionEvent event) {
        if (!player1Chosen) {
            makeChoice(1, "paper");
        }
    }

    @FXML
    private void player1ChooseScissor(ActionEvent event) {
        if (!player1Chosen) {
            makeChoice(1, "scissor");
        }
    }

    // Player 2 action methods
    @FXML
    private void player2ChooseRock(ActionEvent event) {
        if (!player2Chosen) {
            makeChoice(2, "rock");
        }
    }

    @FXML
    private void player2ChoosePaper(ActionEvent event) {
        if (!player2Chosen) {
            makeChoice(2, "paper");
        }
    }

    @FXML
    private void player2ChooseScissor(ActionEvent event) {
        if (!player2Chosen) {
            makeChoice(2, "scissor");
        }
    }

    // Control methods
    @FXML
    private void nextRound(ActionEvent event) {
        resetChoices();
    }

    @FXML
    private void restartGame(ActionEvent event) {
        player1Score = 0;
        player2Score = 0;
        updateScores();
        resetChoices();
        restartBtn.setVisible(false);
    }

    @FXML
    private void returnHome(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/body.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 600, 400));
            stage.setTitle("Game Interface");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
