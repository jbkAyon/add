package com.example.go;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FriendsManager {
    
    public static String generateFriendCode() {
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            code.append(random.nextInt(10));
        }
        return code.toString();
    }
    
    public static String getOrCreateFriendCode(String email) {
        String normalizedEmail = UserStore.normalizeEmail(email);
        
        // First check if user already has a friend code
        String query = "SELECT friend_code FROM users WHERE email = ?";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, normalizedEmail);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String existingCode = rs.getString(1);
                    if (existingCode != null && !existingCode.isEmpty()) {
                        return existingCode;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        
        // Generate unique friend code
        String newCode = generateUniqueFriendCode();
        if (newCode == null) {
            return null;
        }
        
        // Update user with new friend code
        String update = "UPDATE users SET friend_code = ? WHERE email = ?";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(update)) {
            ps.setString(1, newCode);
            ps.setString(2, normalizedEmail);
            ps.executeUpdate();
            return newCode;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static String generateUniqueFriendCode() {
        String code;
        int attempts = 0;
        do {
            code = generateFriendCode();
            attempts++;
            if (attempts > 100) {
                return null; // Prevent infinite loop
            }
        } while (isFriendCodeExists(code));
        return code;
    }
    
    private static boolean isFriendCodeExists(String friendCode) {
        String query = "SELECT COUNT(*) FROM users WHERE friend_code = ?";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, friendCode);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public static String getUserByFriendCode(String friendCode) {
        String query = "SELECT email FROM users WHERE friend_code = ?";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, friendCode);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public static boolean sendFriendRequest(String fromEmail, String toEmail) {
        String normalizedFromEmail = UserStore.normalizeEmail(fromEmail);
        String normalizedToEmail = UserStore.normalizeEmail(toEmail);
        
        if (normalizedFromEmail.equals(normalizedToEmail)) {
            return false; // Can't add yourself
        }
        
        // Check if already friends or request exists
        String checkQuery = "SELECT status FROM friends WHERE " +
                "(user_email = ? AND friend_email = ?) OR " +
                "(user_email = ? AND friend_email = ?)";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(checkQuery)) {
            ps.setString(1, normalizedFromEmail);
            ps.setString(2, normalizedToEmail);
            ps.setString(3, normalizedToEmail);
            ps.setString(4, normalizedFromEmail);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return false; // Already friends or request exists
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        
        // Send friend request
        String insert = "INSERT INTO friends (user_email, friend_email, status) VALUES (?, ?, 'pending')";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(insert)) {
            ps.setString(1, normalizedFromEmail);
            ps.setString(2, normalizedToEmail);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean acceptFriendRequest(String userEmail, String friendEmail) {
        String normalizedUserEmail = UserStore.normalizeEmail(userEmail);
        String normalizedFriendEmail = UserStore.normalizeEmail(friendEmail);
        
        String update = "UPDATE friends SET status = 'accepted' WHERE " +
                "user_email = ? AND friend_email = ? AND status = 'pending'";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(update)) {
            ps.setString(1, normalizedFriendEmail);
            ps.setString(2, normalizedUserEmail);
            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static List<String> getFriends(String email) {
        String normalizedEmail = UserStore.normalizeEmail(email);
        List<String> friends = new ArrayList<>();
        
        String query = "SELECT u.name FROM users u " +
                "JOIN friends f ON u.email = f.friend_email " +
                "WHERE f.user_email = ? AND f.status = 'accepted' " +
                "UNION " +
                "SELECT u.name FROM users u " +
                "JOIN friends f ON u.email = f.user_email " +
                "WHERE f.friend_email = ? AND f.status = 'accepted'";
        
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, normalizedEmail);
            ps.setString(2, normalizedEmail);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    friends.add(rs.getString(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return friends;
    }
    
    public static List<String> getPendingRequests(String email) {
        String normalizedEmail = UserStore.normalizeEmail(email);
        List<String> pendingRequests = new ArrayList<>();
        
        String query = "SELECT u.name FROM users u " +
                "JOIN friends f ON u.email = f.user_email " +
                "WHERE f.friend_email = ? AND f.status = 'pending'";
        
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, normalizedEmail);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    pendingRequests.add(rs.getString(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return pendingRequests;
    }
}
